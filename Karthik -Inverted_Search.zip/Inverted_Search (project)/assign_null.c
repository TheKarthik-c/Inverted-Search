#include"main.h"

void assign_null(main_node **arr)
{
	for(int i=0; i<27; i++ )
	{
		arr[i] = NULL;
	}
}
